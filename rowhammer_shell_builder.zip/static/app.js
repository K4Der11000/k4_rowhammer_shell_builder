
const AUTH_TOKEN = "kader11000";

document.getElementById('payloadForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const ip = document.getElementById('ip').value;
    const port = document.getElementById('port').value;

    fetch('/generate_payload', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': AUTH_TOKEN
        },
        body: JSON.stringify({ ip, port })
    })
    .then(response => response.blob())
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'rowhammer_shell.c';
        document.body.appendChild(a);
        a.click();
        a.remove();
    })
    .catch(error => console.error('Error:', error));
});
